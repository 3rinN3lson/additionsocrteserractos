#Swift Brain
The first neural network / machine learning library written in Swift. This is a project for AI algorithms in Swift for iOS and OS X development. This project includes algorithms focused on Bayes theorem, neural networks, SVMs, Matrices, etc.. Feel free to contribute.

###Development
  Tools:
- [x] Matrix operations
 Machine Learning algorithms
- [ ] Basic regressions
- [x] Kalman filter 
- [x] Neural networks
- [x] Support vector machines
- [ ] Bayesian Classifiers 
- [ ] Clustering
- [ ] Self Organizing
 Statistics
- [ ]  Bayes theorem/naive classifier
- [ ]  Markov model

###Installation and Setup
Podfile coming

###Working Example Application coming.
